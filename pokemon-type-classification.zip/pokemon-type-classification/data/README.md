Place `Pokemon.csv` in this folder.

Source: https://www.kaggle.com/abcsds/pokemon
